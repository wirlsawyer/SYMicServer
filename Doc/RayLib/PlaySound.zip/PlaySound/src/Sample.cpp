#include "PlaySound.h"
#pragma comment (lib, "PlaySound.lib")
int main()
{
	if (!CPlaySound::Init()) return 0;
	if (!CPlaySound::Play()) return 0;

	char buf[20];	//square wave; freq = 8000/20 = 400Hz
	for (int i = 0; i < 10; i++) 
	{
		buf[i] = (unsigned char)(128 - 64); 
		buf[i+10] = (unsigned char)(128 + 64);
	}

	for (int i = 0; i < 800; i++)	//2 second
	{
		if (!CPlaySound::Push(buf, 20)) return 0;
	}
	if (!CPlaySound::Wait()) return 0;

	if (!CPlaySound::Release()) return 0;
	return 0;
}